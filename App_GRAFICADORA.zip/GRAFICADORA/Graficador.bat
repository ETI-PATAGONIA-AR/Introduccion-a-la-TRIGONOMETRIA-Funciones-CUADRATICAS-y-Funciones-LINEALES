@echo off
title Graficador Matematico - ETI Patagonia - prof.martintorres@educ.ar
echo ====================================================================
echo   Graficador Matematico - ETI Patagonia - prof.martintorres@educ.ar
echo ====================================================================
echo.
echo Iniciando...
python "%~dp0graficador.py"
if errorlevel 1 (
    echo.
    echo Ocurrio un error. Asegurate de tener Python instalado.
    echo Si no lo tenes: https://www.python.org/downloads/
    pause
)
