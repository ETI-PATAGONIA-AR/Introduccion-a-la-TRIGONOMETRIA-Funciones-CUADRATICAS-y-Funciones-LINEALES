import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from matplotlib.image import imread
import numpy as np
import os
import sys
import math
from collections import Counter

# ─── PORTABLE ───
carpeta = os.path.dirname(os.path.abspath(__file__))
os.chdir(carpeta)
img_dir = os.path.join(carpeta, "img")

SUP_TRANS = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")

def py_a_notacion(expr):
    """x**2 - 2*x + 1  →  x² − 2·x + 1"""
    s = expr.replace("**3", "³") \
             .replace("**2", "²")
    # x**n -> exponentes con supraindices Unicode
    while "**" in s:
        idx = s.index("**")
        resto = s[idx+2:]
        num = ""
        for c in resto:
            if c.isdigit():
                num += c
            else:
                break
        if num:
            exp_unicode = num.translate(SUP_TRANS)
            s = s[:idx] + exp_unicode + s[idx+2+len(num):]
        else:
            break
    s = s.replace("*", "·") \
         .replace("sqrt", "√") \
         .replace("sin(", "sen(") \
         .replace("cos(", "cos(") \
         .replace("tan(", "tan(") \
         .replace("pi", "π") \
         .replace(" ", "")
    # espacios alrededor de + y -
    for op in "+-":
        s = s.replace(op, " " + op + " ")
    s = s.replace("  ", " ").strip()
    return s

def notacion_a_py(expr):
    s = expr
    s = s.replace("²", "**2").replace("³", "**3")
    s = s.replace("·", "*").replace("√", "sqrt")
    s = s.replace("sen", "sin").replace("π", str(np.pi))
    return s

def mostrar_img(tab, filename, width=5):
    path = os.path.join(img_dir, filename)
    if not os.path.exists(path):
        ttk.Label(tab, text=f"[img: {filename}]", foreground="gray").pack(anchor=tk.W, pady=4)
        return
    fig_i = Figure(figsize=(width, width*0.8), dpi=100)
    ax_i = fig_i.add_subplot(111)
    ax_i.imshow(imread(path))
    ax_i.axis("off")
    fig_i.tight_layout()
    canvas_i = FigureCanvasTkAgg(fig_i, master=tab)
    canvas_i.draw()
    canvas_i.get_tk_widget().pack(fill=tk.BOTH, expand=True, pady=4)

# ─── VENTANA PRINCIPAL ───
root = tk.Tk()
root.title("Graficador Matemático - ETI Patagonia - prof.martintorres@educ.ar")
root.geometry("1200x780")
root.minsize(1000, 680)

style = ttk.Style()
style.theme_use("clam")

main_frame = ttk.Frame(root, padding=6)
main_frame.pack(fill=tk.BOTH, expand=True)

notebook = ttk.Notebook(main_frame)
notebook.pack(fill=tk.BOTH, expand=True)

# ═══════════════════════════════════════════════════════════
# TAB 1: GRAFICADOR
# ═══════════════════════════════════════════════════════════
tab_graf = ttk.Frame(notebook, padding=10)
notebook.add(tab_graf, text="Graficador")

# ─── AREA DE FUNCION ───
frame_func = ttk.LabelFrame(tab_graf, text="Función", padding=8)
frame_func.pack(fill=tk.X)

# Display grande de notacion matematica
display_var = tk.StringVar(value="x² − 2·x − 3")
label_display = tk.Label(frame_func, textvariable=display_var,
                         font=("Segoe UI", 22, "bold"),
                         fg="#1a1a2e", bg="#f8f9fa",
                         anchor=tk.W, padx=12, pady=10,
                         relief=tk.SUNKEN, bd=1)
label_display.pack(fill=tk.X, pady=(0, 6))

ttk.Label(frame_func,
          text="Escribí una función por línea (usá ** para potencia, ej: x**2):",
          foreground="#555").pack(anchor=tk.W)

text_frame = ttk.Frame(frame_func)
text_frame.pack(fill=tk.X)

entry = tk.Text(text_frame, font=("Consolas", 11), height=3,
                padx=6, pady=4, wrap=tk.NONE,
                relief=tk.SUNKEN, bd=1,
                bg="#fafafa", fg="#1a1a2e")
entry.pack(side=tk.LEFT, fill=tk.X, expand=True)

scrollbar = ttk.Scrollbar(text_frame, orient=tk.VERTICAL, command=entry.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
entry.configure(yscrollcommand=scrollbar.set)

entry.insert("1.0", "x**2 - 2*x - 3\n2*x - 1\nsin(x)")
entry.focus()

COLORES = ['#1f77b4', '#d62728', '#2ca02c', '#ff7f0e',
           '#9467bd', '#8c564b', '#e377c2', '#17becf']

def obtener_funciones():
    raw = entry.get("1.0", tk.END).strip()
    lineas = []
    for l in raw.split("\n"):
        l = l.strip()
        if l and not l.startswith("#"):
            lineas.append(l)
    return lineas

def actualizar_display():
    funcs = obtener_funciones()
    if not funcs:
        display_var.set("(vacío)")
        return
    partes = []
    for i, f in enumerate(funcs):
        c = COLORES[i % len(COLORES)]
        nombre = py_a_notacion(f)
        partes.append(f"■ {nombre}")
    display_var.set("   |   ".join(partes))

entry.bind("<KeyRelease>", lambda e: actualizar_display())
actualizar_display()

# ─── BOTONES MATEMATICOS ───
frame_botones = ttk.LabelFrame(tab_graf, text="Herramientas", padding=6)
frame_botones.pack(fill=tk.X, pady=6)

def insertar(texto):
    try:
        entry.insert(tk.INSERT, texto)
    except:
        entry.insert("insert", texto)
    entry.focus()

botones = [
    (" ( ", "("), (" ) ", ")"),
    (" + ", "+"), (" − ", "-"),
    (" × ", "*"), (" ÷ ", "/"),
    (" x² ", "**2"), (" x³ ", "**3"),
    (" xⁿ ", "**"), (" √ ", "sqrt("),
    (" sen ", "sin("), (" cos ", "cos("),
    (" tan ", "tan("), (" π ", str(np.pi)),
]

for label, valor in botones:
    btn = tk.Button(frame_botones, text=label,
                    command=lambda v=valor: insertar(v),
                    font=("Segoe UI", 9, "bold"),
                    bg="#e8e8e8", relief=tk.RAISED,
                    padx=5, pady=1, cursor="hand2")
    btn.pack(side=tk.LEFT, padx=2, pady=2)

# ─── RANGOS ───
frame_rangos = ttk.Frame(tab_graf)
frame_rangos.pack(fill=tk.X, pady=2)

ttk.Label(frame_rangos, text="X desde:").pack(side=tk.LEFT)
xmin_var = tk.StringVar(value="-10")
txmin = ttk.Entry(frame_rangos, textvariable=xmin_var, width=5)
txmin.pack(side=tk.LEFT, padx=2)

ttk.Label(frame_rangos, text="hasta:").pack(side=tk.LEFT)
xmax_var = tk.StringVar(value="10")
txmax = ttk.Entry(frame_rangos, textvariable=xmax_var, width=5)
txmax.pack(side=tk.LEFT, padx=2)

ttk.Label(frame_rangos, text="  Y auto").pack(side=tk.LEFT)
auto_y_var = tk.BooleanVar(value=True)
ttk.Checkbutton(frame_rangos, variable=auto_y_var).pack(side=tk.LEFT)

# ─── BOTONES DE ACCION ───
frame_btn = ttk.Frame(tab_graf)
frame_btn.pack(fill=tk.X, pady=4)

# ─── GRAFICO ───
fig = Figure(figsize=(8, 4.5), dpi=100)
ax = fig.add_subplot(111)
ax.grid(True, linestyle="--", alpha=0.5)
ax.axhline(y=0, color="black", linewidth=0.8)
ax.axvline(x=0, color="black", linewidth=0.8)

canvas = FigureCanvasTkAgg(fig, master=tab_graf)
canvas_widget = canvas.get_tk_widget()
canvas_widget.pack(fill=tk.BOTH, expand=True, pady=4)

def graficar():
    funcs = obtener_funciones()
    if not funcs:
        messagebox.showwarning("Falta función", "Escribí al menos una función")
        return
    try:
        xmin = float(xmin_var.get())
        xmax = float(xmax_var.get())
    except:
        messagebox.showerror("Error", "X min y X max deben ser números")
        return
    if xmin >= xmax:
        messagebox.showerror("Error", "X min debe ser menor que X max")
        return

    x = np.linspace(xmin, xmax, 800)

    ax.cla()
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.axhline(y=0, color="black", linewidth=0.8)
    ax.axvline(x=0, color="black", linewidth=0.8)

    nombres = []
    for i, expr in enumerate(funcs):
        try:
            expr_py = notacion_a_py(expr)
            y = eval(expr_py, {"__builtins__": {}}, {"x": x, "sin": np.sin, "cos": np.cos,
                 "tan": np.tan, "sqrt": np.sqrt, "pi": np.pi, "abs": np.abs,
                 "log": np.log, "exp": np.exp})
            if isinstance(y, (int, float)):
                y = np.full_like(x, y, dtype=float)
            y = np.where(np.abs(y) > 1e6, np.nan, y)
        except Exception as e:
            messagebox.showerror(f"Error en línea {i+1}", f"{expr}\n{str(e)}")
            return

        color = COLORES[i % len(COLORES)]
        nombre = py_a_notacion(expr)
        ax.plot(x, y, color=color, linewidth=2, label=nombre)

    ax.set_xlim(xmin, xmax)
    if auto_y_var.get():
        ax.relim()
        ax.autoscale_view()
        yl = ax.get_ylim()
        if yl[0] < -100: ax.set_ylim(bottom=-100)
        if yl[1] > 100: ax.set_ylim(top=100)

    ax.legend(fontsize=9)
    fig.tight_layout()
    canvas.draw()
    n = len(funcs)
    status_var.set(f"{n} función{'es' if n>1 else ''} graficada{'s' if n>1 else ''}")

def limpiar():
    ax.cla()
    ax.grid(True, linestyle="--", alpha=0.5)
    ax.axhline(y=0, color="black", linewidth=0.8)
    ax.axvline(x=0, color="black", linewidth=0.8)
    ax.set_xlim(-10, 10)
    ax.set_ylim(-10, 10)
    fig.tight_layout()
    canvas.draw()
    status_var.set("Pantalla limpia")

def guardar_png():
    path = os.path.join(carpeta, "grafico.png")
    fig.savefig(path, dpi=150, bbox_inches="tight")
    status_var.set(f"Guardado: {path}")

# Crear botones despues de definir las funciones
btn_graficar = tk.Button(frame_btn, text="GRAFICAR",
                         command=graficar, font=("Segoe UI", 12, "bold"),
                         bg="#2d6a4f", fg="white",
                         padx=25, pady=4, cursor="hand2",
                         activebackground="#40916c")
btn_graficar.pack(side=tk.LEFT, padx=3)

ttk.Button(frame_btn, text="Limpiar", command=limpiar, width=10).pack(side=tk.LEFT, padx=3)
ttk.Button(frame_btn, text="Guardar PNG", command=guardar_png, width=12).pack(side=tk.LEFT, padx=3)

status_var = tk.StringVar(value="Listo")
status_bar = ttk.Label(tab_graf, textvariable=status_var, relief=tk.SUNKEN, anchor=tk.W)
status_bar.pack(fill=tk.X, pady=(4, 0))

# ═══════════════════════════════════════════════════════════
# TAB 2: TEOREMAS
# ═══════════════════════════════════════════════════════════
tab_teo = ttk.Frame(notebook, padding=10)
notebook.add(tab_teo, text="Teoremas")

teo_notebook = ttk.Notebook(tab_teo)
teo_notebook.pack(fill=tk.BOTH, expand=True)

# ─── PITAGORAS ───
tab_pit = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_pit, text="Pitágoras")

f_pit_top = ttk.Frame(tab_pit)
f_pit_top.pack(fill=tk.X)
f_pit_izq = ttk.Frame(f_pit_top)
f_pit_izq.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
f_pit_der = ttk.Frame(f_pit_top)
f_pit_der.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(15, 0))

ttk.Label(f_pit_izq, text="Teorema de Pitágoras:",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(f_pit_izq, text="a² + b² = c²",
          font=("Segoe UI", 16, "bold"), foreground="#1a1a2e").pack(anchor=tk.W, pady=4)
ttk.Label(f_pit_izq, text="Dejá vacío el valor que querés calcular.",
          foreground="gray").pack(anchor=tk.W, pady=(0, 8))

f_pit = ttk.Frame(f_pit_izq)
f_pit.pack(fill=tk.X)
ttk.Label(f_pit, text="a (cateto):", font=("Segoe UI", 11)).grid(row=0, column=0, sticky=tk.W, pady=3)
pit_a = ttk.Entry(f_pit, width=10, font=("Consolas", 11))
pit_a.grid(row=0, column=1, padx=5, pady=3)
ttk.Label(f_pit, text="b (cateto):", font=("Segoe UI", 11)).grid(row=1, column=0, sticky=tk.W, pady=3)
pit_b = ttk.Entry(f_pit, width=10, font=("Consolas", 11))
pit_b.grid(row=1, column=1, padx=5, pady=3)
ttk.Label(f_pit, text="c (hipotenusa):", font=("Segoe UI", 11)).grid(row=2, column=0, sticky=tk.W, pady=3)
pit_c = ttk.Entry(f_pit, width=10, font=("Consolas", 11))
pit_c.grid(row=2, column=1, padx=5, pady=3)

pit_resultado = tk.StringVar()
ttk.Label(f_pit, textvariable=pit_resultado, font=("Segoe UI", 11, "bold"),
          foreground="#0066cc", wraplength=400).grid(row=3, column=0, columnspan=2, pady=8)

def calc_pitagoras():
    try:
        a_str = pit_a.get().strip()
        b_str = pit_b.get().strip()
        c_str = pit_c.get().strip()
        vacios = sum(1 for x in [a_str, b_str, c_str] if x == "")
        if vacios != 1:
            pit_resultado.set("⚠ Dejá UN solo valor vacío (el que querés calcular)")
            return
        if a_str and b_str:
            a, b = float(a_str), float(b_str)
            c = math.sqrt(a**2 + b**2)
            pit_resultado.set(f"c = √({a}² + {b}²) = √{a**2 + b**2:.2f} = {c:.3f}")
        elif a_str and c_str:
            a, c = float(a_str), float(c_str)
            if c <= a:
                pit_resultado.set("⚠ La hipotenusa debe ser mayor que el cateto")
                return
            b = math.sqrt(c**2 - a**2)
            pit_resultado.set(f"b = √({c}² − {a}²) = √{c**2 - a**2:.2f} = {b:.3f}")
        elif b_str and c_str:
            b, c = float(b_str), float(c_str)
            if c <= b:
                pit_resultado.set("⚠ La hipotenusa debe ser mayor que el cateto")
                return
            a = math.sqrt(c**2 - b**2)
            pit_resultado.set(f"a = √({c}² − {b}²) = √{c**2 - b**2:.2f} = {a:.3f}")
    except ValueError:
        pit_resultado.set("⚠ Ingresá números válidos")
    except Exception as e:
        pit_resultado.set(f"⚠ Error: {str(e)}")

tk.Button(tab_pit, text="RESULTADO", command=calc_pitagoras,
          font=("Segoe UI", 10, "bold"), bg="#2d6a4f", fg="white",
          cursor="hand2").pack(anchor=tk.W, pady=5)
ttk.Label(tab_pit, text="💡 Si tenés los dos catetos → calculás la hipotenusa.\n   Si tenés un cateto + hipotenusa → calculás el otro cateto.",
          foreground="gray", justify=tk.LEFT).pack(anchor=tk.W, pady=4)

# Grafico de triangulo
mostrar_img(f_pit_der, "14_triangulo_rotulado.png", width=4)

# ─── CUADRATICA ───
tab_bhas = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_bhas, text="Fórmula Cuadrática")

f_bhas_top = ttk.Frame(tab_bhas)
f_bhas_top.pack(fill=tk.X)
f_bhas_izq = ttk.Frame(f_bhas_top)
f_bhas_izq.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
f_bhas_der = ttk.Frame(f_bhas_top)
f_bhas_der.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(15, 0))

ttk.Label(f_bhas_izq, text="Ecuación:  ax² + bx + c = 0",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(f_bhas_izq, text="Completá a, b y c para hallar las raíces.",
          foreground="gray").pack(anchor=tk.W, pady=(0, 8))

f_bhas = ttk.Frame(f_bhas_izq)
f_bhas.pack(fill=tk.X)
for i, (l, v) in enumerate([("a:", "1"), ("b:", "0"), ("c:", "0")]):
    ttk.Label(f_bhas, text=l, font=("Segoe UI", 11)).grid(row=i, column=0, sticky=tk.W, pady=3)
    var = tk.StringVar(value=v)
    setattr(tab_bhas, f"bhas_{l[0]}", var)
    ttk.Entry(f_bhas, width=8, font=("Consolas", 11), textvariable=var).grid(row=i, column=1, padx=5, pady=3, sticky=tk.W)

bhas_resultado = tk.StringVar()
ttk.Label(f_bhas, textvariable=bhas_resultado, font=("Segoe UI", 11, "bold"),
          foreground="#0066cc", wraplength=400).grid(row=3, column=0, columnspan=2, pady=8)

def calc_bhaskara():
    try:
        a = float(tab_bhas.bhas_a.get())
        b = float(tab_bhas.bhas_b.get())
        c_ = float(tab_bhas.bhas_c.get())
    except:
        bhas_resultado.set("⚠ Ingresá números válidos para a, b y c")
        return
    if a == 0:
        bhas_resultado.set("⚠ 'a' no puede ser cero (no es cuadrática)")
        return
    delta = b**2 - 4*a*c_
    if delta < 0:
        bhas_resultado.set(f"Δ = {delta:.2f}  →  NO tiene raíces reales (Δ < 0)")
    elif abs(delta) < 1e-12:
        x = -b / (2*a)
        bhas_resultado.set(f"Δ = 0  →  Una raíz doble: x = {x:.4f}")
    else:
        x1 = (-b + math.sqrt(delta)) / (2*a)
        x2 = (-b - math.sqrt(delta)) / (2*a)
        bhas_resultado.set(f"Δ = {delta:.2f}  →  x₁ = {x1:.4f}  |  x₂ = {x2:.4f}")

tk.Button(tab_bhas, text="RESULTADO", command=calc_bhaskara,
          font=("Segoe UI", 10, "bold"), bg="#2d6a4f", fg="white",
          cursor="hand2").pack(anchor=tk.W, pady=5)

# Graficos de cuadraticas
f_bhas_graf = ttk.Frame(f_bhas_der)
f_bhas_graf.pack(fill=tk.BOTH, expand=True)
mostrar_img(f_bhas_der, "24_cuadratica_detallada.png", width=4.5)
ttk.Label(f_bhas_der, text="Ejemplo: y = x² − 2x − 3", foreground="gray",
          font=("Segoe UI", 9)).pack()

# ─── SOH CAH TOA ───
tab_trig = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_trig, text="SOH CAH TOA")

f_trig_top = ttk.Frame(tab_trig)
f_trig_top.pack(fill=tk.X)
f_trig_izq = ttk.Frame(f_trig_top)
f_trig_izq.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
f_trig_der = ttk.Frame(f_trig_top)
f_trig_der.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(15, 0))

ttk.Label(f_trig_izq, text="Resolver triángulo rectángulo",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(f_trig_izq, text="Elegí qué querés calcular:",
          foreground="gray").pack(anchor=tk.W, pady=(0, 6))

f_trig_tipo = ttk.Frame(f_trig_izq)
f_trig_tipo.pack(fill=tk.X)
tipo_trig = tk.StringVar(value="lado")
ttk.Radiobutton(f_trig_tipo, text="Hallar un LADO (tengo ángulo + 1 lado)",
                variable=tipo_trig, value="lado").pack(anchor=tk.W)
ttk.Radiobutton(f_trig_tipo, text="Hallar un ÁNGULO (tengo 2 lados)",
                variable=tipo_trig, value="angulo").pack(anchor=tk.W)

f_trig = ttk.Frame(f_trig_izq)
f_trig.pack(fill=tk.X, pady=4)

ttk.Label(f_trig, text="Ángulo (°):", font=("Segoe UI", 10)).grid(row=0, column=0, sticky=tk.W, pady=2)
trig_ang = ttk.Entry(f_trig, width=8, font=("Consolas", 10))
trig_ang.grid(row=0, column=1, padx=4, pady=2, sticky=tk.W)

ttk.Label(f_trig, text="¿Qué lado tengo? :", font=("Segoe UI", 10)).grid(row=1, column=0, sticky=tk.W, pady=2)
lado_tengo = ttk.Combobox(f_trig, values=["Opuesto", "Adyacente", "Hipotenusa"], width=12, state="readonly")
lado_tengo.grid(row=1, column=1, padx=4, pady=2, sticky=tk.W)
lado_tengo.set("Opuesto")

ttk.Label(f_trig, text="Valor del lado:", font=("Segoe UI", 10)).grid(row=2, column=0, sticky=tk.W, pady=2)
trig_lado = ttk.Entry(f_trig, width=8, font=("Consolas", 10))
trig_lado.grid(row=2, column=1, padx=4, pady=2, sticky=tk.W)

ttk.Label(f_trig, text="¿Qué lado busco? :", font=("Segoe UI", 10)).grid(row=3, column=0, sticky=tk.W, pady=2)
lado_busco = ttk.Combobox(f_trig, values=["Opuesto", "Adyacente", "Hipotenusa"], width=12, state="readonly")
lado_busco.grid(row=3, column=1, padx=4, pady=2, sticky=tk.W)
lado_busco.set("Hipotenusa")

MAP_TRI = {
    ("Opuesto", "Hipotenusa"): ("sen", lambda a, v: v / math.sin(math.radians(a))),
    ("Hipotenusa", "Opuesto"): ("sen", lambda a, v: v * math.sin(math.radians(a))),
    ("Adyacente", "Hipotenusa"): ("cos", lambda a, v: v / math.cos(math.radians(a))),
    ("Hipotenusa", "Adyacente"): ("cos", lambda a, v: v * math.cos(math.radians(a))),
    ("Opuesto", "Adyacente"): ("tan", lambda a, v: v / math.tan(math.radians(a))),
    ("Adyacente", "Opuesto"): ("tan", lambda a, v: v * math.tan(math.radians(a))),
}

ttk.Label(f_trig, text="— O: Hallar ángulo —", font=("Segoe UI", 10, "italic"),
          foreground="gray").grid(row=5, column=0, columnspan=2, pady=(8, 2))
ttk.Label(f_trig, text="Cateto Opuesto:", font=("Segoe UI", 10)).grid(row=6, column=0, sticky=tk.W, pady=2)
trig_opu = ttk.Entry(f_trig, width=8, font=("Consolas", 10))
trig_opu.grid(row=6, column=1, padx=4, pady=2, sticky=tk.W)
ttk.Label(f_trig, text="Cateto Adyacente:", font=("Segoe UI", 10)).grid(row=7, column=0, sticky=tk.W, pady=2)
trig_ady = ttk.Entry(f_trig, width=8, font=("Consolas", 10))
trig_ady.grid(row=7, column=1, padx=4, pady=2, sticky=tk.W)
ttk.Label(f_trig, text="Hipotenusa:", font=("Segoe UI", 10)).grid(row=8, column=0, sticky=tk.W, pady=2)
trig_hip = ttk.Entry(f_trig, width=8, font=("Consolas", 10))
trig_hip.grid(row=8, column=1, padx=4, pady=2, sticky=tk.W)

trig_resultado = tk.StringVar()
ttk.Label(f_trig, textvariable=trig_resultado, font=("Segoe UI", 11, "bold"),
          foreground="#0066cc", wraplength=400).grid(row=9, column=0, columnspan=2, pady=6)

def calc_trigonometria():
    if tipo_trig.get() == "lado":
        try:
            ang = float(trig_ang.get())
            val = float(trig_lado.get())
            tengo = lado_tengo.get()
            busco = lado_busco.get()
            key = (tengo, busco)
            if key in MAP_TRI:
                nom, fn = MAP_TRI[key]
                res = fn(ang, val)
                trig_resultado.set(f"{nom}({ang}°) = {busco.lower()} / {tengo.lower()}\n→ {busco} = {res:.3f}")
            else:
                trig_resultado.set("⚠ Combinación no reconocida")
        except ValueError:
            trig_resultado.set("⚠ Ingresá números válidos")
        except Exception as e:
            trig_resultado.set(f"⚠ Error: {str(e)}")
    else:
        try:
            opu = trig_opu.get().strip()
            ady = trig_ady.get().strip()
            hip = trig_hip.get().strip()
            if opu and hip:
                v = float(opu) / float(hip)
                ang = math.degrees(math.asin(v))
                trig_resultado.set(f"sen(θ) = {opu}/{hip} = {v:.4f}  →  θ = {ang:.2f}°")
            elif ady and hip:
                v = float(ady) / float(hip)
                ang = math.degrees(math.acos(v))
                trig_resultado.set(f"cos(θ) = {ady}/{hip} = {v:.4f}  →  θ = {ang:.2f}°")
            elif opu and ady:
                v = float(opu) / float(ady)
                ang = math.degrees(math.atan(v))
                trig_resultado.set(f"tan(θ) = {opu}/{ady} = {v:.4f}  →  θ = {ang:.2f}°")
            else:
                trig_resultado.set("⚠ Completá dos lados para hallar el ángulo")
        except:
            trig_resultado.set("⚠ Ingresá números válidos")

tk.Button(tab_trig, text="RESULTADO", command=calc_trigonometria,
          font=("Segoe UI", 10, "bold"), bg="#2d6a4f", fg="white",
          cursor="hand2").pack(anchor=tk.W, pady=5)

# Graficos
mostrar_img(f_trig_der, "22_triangulo_30_grados.png", width=4)
ttk.Label(f_trig_der, text="Ejemplo: triángulo 30° con lados",
          foreground="gray", font=("Segoe UI", 9)).pack()

# ─── LEY DE SENO / COSENO ───
tab_ley = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_ley, text="Ley Seno/Coseno")

ttk.Label(tab_ley, text="Ley del Seno:",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(tab_ley, text="a / sen(A) = b / sen(B) = c / sen(C)",
          font=("Segoe UI", 13), foreground="#1a1a2e").pack(anchor=tk.W, pady=4)
ttk.Label(tab_ley, text="Usala cuando conocés: 2 ángulos y 1 lado, o 2 lados y 1 ángulo (no recto).",
          foreground="gray", wraplength=600, justify=tk.LEFT).pack(anchor=tk.W, pady=2)

ttk.Label(tab_ley, text="").pack()
ttk.Label(tab_ley, text="Ley del Coseno:",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(tab_ley, text="a² = b² + c² − 2·b·c·cos(A)",
          font=("Segoe UI", 13), foreground="#1a1a2e").pack(anchor=tk.W, pady=4)
ttk.Label(tab_ley, text="Usala cuando conocés: 2 lados y el ángulo entre ellos, o 3 lados.",
          foreground="gray", wraplength=600, justify=tk.LEFT).pack(anchor=tk.W, pady=2)

ttk.Label(tab_ley, text="").pack()
ttk.Label(tab_ley, text="💡 Estas leyes sirven para triángulos que NO son rectángulos.\n   Si el triángulo tiene un ángulo recto, usá SOH CAH TOA.",
          foreground="gray", justify=tk.LEFT).pack(anchor=tk.W)

# ─── RECTA ───
tab_recta = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_recta, text="Pendiente y Recta")

f_recta_top = ttk.Frame(tab_recta)
f_recta_top.pack(fill=tk.X)
f_recta_izq = ttk.Frame(f_recta_top)
f_recta_izq.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
f_recta_der = ttk.Frame(f_recta_top)
f_recta_der.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(15, 0))

ttk.Label(f_recta_izq, text="Pendiente y ecuación de la recta",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(f_recta_izq, text="Dados dos puntos (x₁, y₁) y (x₂, y₂):",
          foreground="gray").pack(anchor=tk.W, pady=(0, 6))

f_recta = ttk.Frame(f_recta_izq)
f_recta.pack(fill=tk.X)
recta_vars = {}
for i, (l, d) in enumerate([("x₁:", "0"), ("y₁:", "0"), ("x₂:", "1"), ("y₂:", "1")]):
    ttk.Label(f_recta, text=l, font=("Segoe UI", 11)).grid(row=i//2, column=(i%2)*2, sticky=tk.W, padx=(0, 2), pady=3)
    var = tk.StringVar(value=d)
    recta_vars[l] = var
    ttk.Entry(f_recta, width=8, font=("Consolas", 11), textvariable=var).grid(row=i//2, column=(i%2)*2+1, padx=(0, 15), pady=3, sticky=tk.W)

recta_resultado = tk.StringVar()
ttk.Label(f_recta, textvariable=recta_resultado, font=("Segoe UI", 11, "bold"),
          foreground="#0066cc", wraplength=400).grid(row=2, column=0, columnspan=4, pady=8)

def calc_recta():
    try:
        x1 = float(recta_vars["x₁:"].get())
        y1 = float(recta_vars["y₁:"].get())
        x2 = float(recta_vars["x₂:"].get())
        y2 = float(recta_vars["y₂:"].get())
    except:
        recta_resultado.set("⚠ Ingresá números válidos")
        return
    if abs(x2 - x1) < 1e-12:
        recta_resultado.set("⚠ x₁ = x₂ → recta vertical (pendiente infinita)")
        return
    m = (y2 - y1) / (x2 - x1)
    b = y1 - m * x1
    sube = "sube" if m > 0 else "baja" if m < 0 else "es horizontal"
    signo = "+" if b >= 0 else ""
    recta_resultado.set(f"m = ({y2}−{y1})/({x2}−{x1}) = {m:.3f}\n"
                        f"b = {b:.3f}\n"
                        f"→ y = {m:.3f}x {signo}{b:.3f}\n"
                        f"→ La recta {sube}")

tk.Button(tab_recta, text="RESULTADO", command=calc_recta,
          font=("Segoe UI", 10, "bold"), bg="#2d6a4f", fg="white",
          cursor="hand2").pack(anchor=tk.W, pady=5)

mostrar_img(f_recta_der, "28_pendiente_dos_puntos.png", width=4)

# ─── ESTADISTICA ───
tab_est = ttk.Frame(teo_notebook, padding=12)
teo_notebook.add(tab_est, text="Estadística")

ttk.Label(tab_est, text="Promedio, mediana y moda",
          font=("Segoe UI", 14, "bold")).pack(anchor=tk.W)
ttk.Label(tab_est, text="Ingresá los números separados por coma (ej: 5, 8, 12, 15):",
          foreground="gray").pack(anchor=tk.W, pady=(0, 6))

est_entry = ttk.Entry(tab_est, font=("Consolas", 11))
est_entry.pack(fill=tk.X)

est_resultado = tk.StringVar()
ttk.Label(tab_est, textvariable=est_resultado, font=("Segoe UI", 11, "bold"),
          foreground="#0066cc", wraplength=700).pack(anchor=tk.W, pady=6)

def calc_est():
    raw = est_entry.get().strip()
    if not raw:
        est_resultado.set("⚠ Ingresá al menos un número")
        return
    try:
        nums = [float(x.strip()) for x in raw.split(",")]
    except:
        est_resultado.set("⚠ Usá números separados por coma")
        return
    n = len(nums)
    prom = sum(nums) / n
    nums_ord = sorted(nums)
    med = nums_ord[n//2] if n % 2 else (nums_ord[n//2-1] + nums_ord[n//2]) / 2
    cnt = Counter(nums_ord)
    max_f = max(cnt.values())
    modas = [k for k, v in cnt.items() if v == max_f]
    moda_str = ", ".join(f"{v:.2f}" for v in modas) if len(modas) < len(nums) else "No hay moda única"
    est_resultado.set(f"n = {n}  |  Promedio = {prom:.2f}  |  Mediana = {med:.2f}  |  Moda = {moda_str}")

tk.Button(tab_est, text="RESULTADO", command=calc_est,
          font=("Segoe UI", 10, "bold"), bg="#2d6a4f", fg="white",
          cursor="hand2").pack(anchor=tk.W, pady=5)

# ─── GRAFICAR AL INICIAR ───
root.after(500, graficar)
root.mainloop()
